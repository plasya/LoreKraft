# node.py

class Node:
    def __init__(self, key, image):
        self.key = key       # Key for the node
        self.image = image   # Image data (e.g., file path)
        self.next = None     # Pointer to the next node
        self.prev = None     # Pointer to the previous node