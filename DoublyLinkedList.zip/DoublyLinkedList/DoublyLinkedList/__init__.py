# __init__.py
from .doubly_linked_list import DoublyLinkedList
