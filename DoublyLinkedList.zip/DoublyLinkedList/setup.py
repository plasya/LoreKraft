# setup.py

from setuptools import setup, find_packages

setup(
    name="doubly_linked_list",
    version="0.1",
    description="A Python package for a doubly linked list with key and image at each node",
    author="Your Name",
    author_email="your.email@example.com",
    packages=find_packages(),
    install_requires=[],  # Add dependencies if necessary
)
